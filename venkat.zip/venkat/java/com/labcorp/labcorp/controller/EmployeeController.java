package com.labcorp.labcorp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.labcorp.labcorp.dto.Employee;
import com.labcorp.labcorp.dto.EmployeeResponse;
import com.labcorp.labcorp.service.EmployeeService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class EmployeeController {
	
	@Autowired
	private EmployeeService empService;
	
	 @PostMapping("/employees")
	public EmployeeResponse getEmployeeList(@RequestBody Employee employee) {
		 return empService.TakeVacation(employee);
		
	}
}
