package com.labcorp.labcorp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabcorpApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabcorpApplication.class, args);
	}

}
