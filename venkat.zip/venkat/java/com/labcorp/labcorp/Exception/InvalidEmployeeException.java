package com.labcorp.labcorp.Exception;

public class InvalidEmployeeException extends RuntimeException {

	public InvalidEmployeeException(String msg) {
		super(msg);
	}
	
}
