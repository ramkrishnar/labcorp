package com.labcorp.labcorp.util;

import java.util.ArrayList;
import java.util.List;

import com.labcorp.labcorp.dto.Employee;

public class EmployeeUtil {
	
	public static List<Employee> getEmployeeList(){
		List<Employee> empList=new ArrayList();
		Employee hrsemp=new Employee();
		Employee salemp=new Employee();
		Employee mgremp=new Employee();
		hrsemp.setEmployeeType("hourly");
		hrsemp.setVacation(10.0f);
		hrsemp.setWorkDays(260);
		salemp.setEmployeeType("salaried");
		salemp.setVacation(15.0f);
		salemp.setWorkDays(260);
		mgremp.setEmployeeType("managers");
		mgremp.setVacation(30.0f);
		mgremp.setWorkDays(260);
		empList.add(hrsemp);
		empList.add(salemp);
		empList.add(mgremp);
		return empList;
	}

}
