package com.labcorp.labcorp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.labcorp.labcorp.Exception.InvalidEmployeeException;
import com.labcorp.labcorp.dto.Employee;
import com.labcorp.labcorp.dto.EmployeeResponse;
import com.labcorp.labcorp.util.EmployeeUtil;

@Service
public class EmployeeService {
	
	
	public int work(int workDays) {
		
		int leftDays=260-workDays;
		
		return leftDays;
	}
	
	
	public EmployeeResponse TakeVacation(Employee emp) {
		List<Employee> empList=EmployeeUtil.getEmployeeList();
		EmployeeResponse response=new EmployeeResponse();
		try {
		if(!empList.isEmpty()) {
			Optional<Employee> emp1=empList.stream().filter(e->e.getEmployeeType()
					.equalsIgnoreCase(emp.getEmployeeType())).findFirst();
			Employee e=emp1.get();
			System.out.print(e.getEmployeeType()+" "+e.getVacation());
			int workDays=(int) (work(emp.getWorkDays())-emp.getVacation());
			float vacationDays=e.getVacation()-emp.getVacation();
			response.setEmployeeType(e.getEmployeeType());
			response.setAvailableworkDays(workDays);
			response.setAvailableVacations(vacationDays);		
		}
		}catch(Exception ex) {
			throw new InvalidEmployeeException("Invalid Employee Details :"+ex.getMessage());
		}
		return response;
	}

}
