package com.labcorp.labcorp.dto;

public class EmployeeResponse {
	
	private int availableworkDays;
	private float availableVacations;
	private String employeeType;
	
	
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public int getAvailableworkDays() {
		return availableworkDays;
	}
	public void setAvailableworkDays(int availableworkDays) {
		this.availableworkDays = availableworkDays;
	}
	public float getAvailableVacations() {
		return availableVacations;
	}
	public void setAvailableVacations(float availableVacations) {
		this.availableVacations = availableVacations;
	}
	

}
