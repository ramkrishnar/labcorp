package com.labcorp.labcorp.dto;

public class Employee {
	private String employeeType;
	private int workDays;
	private float vacation;
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public int getWorkDays() {
		return workDays;
	}
	public void setWorkDays(int workDays) {
		this.workDays = workDays;
	}
	public float getVacation() {
		return vacation;
	}
	public void setVacation(float vacation) {
		this.vacation = vacation;
	}
	
	
	

}
