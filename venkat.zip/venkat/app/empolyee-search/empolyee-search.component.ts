import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../empolyee.service';

@Component({
  selector: 'app-empolyee-search',
  templateUrl: './empolyee-search.component.html',
  styleUrls: ['./empolyee-search.component.css']
})
export class EmpolyeeSearchComponent implements OnInit {
  employeeType='';
  workDays='';
  vacation='';
  availableVacations="";
  availableworkDays='';
  empType='';
  constructor(private employeeService: EmployeeService) { }

  ngOnInit() {
  }
  getEmployee(){
    this.employeeService
    .getEmployee({"employeeType":this.employeeType,"workDays":this.workDays,"vacation":this.vacation}).subscribe(data => {
      console.log(data)
      this.availableVacations=data.availableVacations;
      this.availableworkDays=data.availableworkDays;
      this.empType=data.employeeType;
    }, 
    error => console.log(error));
  }
}
