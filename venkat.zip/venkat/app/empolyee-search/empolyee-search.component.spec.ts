import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpolyeeSearchComponent } from './empolyee-search.component';

describe('EmpolyeeSearchComponent', () => {
  let component: EmpolyeeSearchComponent;
  let fixture: ComponentFixture<EmpolyeeSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpolyeeSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpolyeeSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
