import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmpolyeeSearchComponent } from './empolyee-search/empolyee-search.component';

const routes: Routes = [
  { path: '', redirectTo: 'employee', pathMatch: 'full' },
  { path: 'employees', component: EmpolyeeSearchComponent },

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
